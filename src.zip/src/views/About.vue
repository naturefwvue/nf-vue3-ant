<template>
  <div class="about">
    <h1 @click="myClick">This is an about page</h1>
    <a-input v-model:value="modelValue.name" placeholder="companyCode" /> <br>
    {{value}}<br>{{modelValue.name}}

    <a-input-search placeholder="input search loading deault"
        :loading="isLoding" />
  </div>
</template>

<script>
// @ is an alias to /src
import { ref, registerRuntimeCompiler } from 'vue'

export default {
  name: 'About',
  setup () {
    const value = ref('11')
    const modelValue = ref({
      name: '2222'
    })
    const isLoding = ref(false)
    const myClick = () => {
      isLoding.value = !isLoding.value
    }
    return {
      value,
      modelValue,
      isLoding,
      myClick
    }
  }
}
</script>
